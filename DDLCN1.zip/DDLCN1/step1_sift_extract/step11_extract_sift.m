tic
clear all;close all;clc

original_image_dir = '../Datasets/caltech101';
feature_dir = '../step1_sift_extract/sift_feature/caltech101';
extr_sift(original_image_dir, feature_dir);

toc